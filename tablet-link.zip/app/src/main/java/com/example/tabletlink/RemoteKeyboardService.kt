package com.example.tabletlink

import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.widget.TextView

class RemoteKeyboardService : InputMethodService() {
    companion object { @Volatile var instance: RemoteKeyboardService? = null }
    private val main = Handler(Looper.getMainLooper())

    override fun onCreate() { super.onCreate(); instance = this }
    override fun onDestroy() { instance = null; super.onDestroy() }

    override fun onCreateInputView(): View = TextView(this).apply {
        text = "Remote keyboard active: type on the laptop.\nSwitch back to your normal keyboard with the keyboard icon."
        setPadding(40, 30, 40, 30)
        textSize = 16f
    }

    fun typeText(s: String) { main.post { currentInputConnection?.commitText(s, 1) } }

    fun key(code: Int, meta: Int = 0) {
        main.post {
            val ic = currentInputConnection ?: return@post
            val t = SystemClock.uptimeMillis()
            ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_DOWN, code, 0, meta))
            ic.sendKeyEvent(KeyEvent(t, t, KeyEvent.ACTION_UP, code, 0, meta))
        }
    }
}
