package com.example.tabletlink

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context

@SuppressLint("MissingPermission")
class HidMouse(private val ctx: Context, private val onState: (String) -> Unit) {
    private val adapter: BluetoothAdapter? = ctx.getSystemService(BluetoothManager::class.java)?.adapter
    private var hid: BluetoothHidDevice? = null
    private var host: BluetoothDevice? = null

    private val descriptor = intArrayOf(
        0x05,0x01,0x09,0x02,0xA1,0x01,0x09,0x01,0xA1,0x00,0x05,0x09,0x19,0x01,0x29,0x03,
        0x15,0x00,0x25,0x01,0x95,0x03,0x75,0x01,0x81,0x02,0x95,0x01,0x75,0x05,0x81,0x03,
        0x05,0x01,0x09,0x30,0x09,0x31,0x09,0x38,0x15,0x81,0x25,0x7F,0x75,0x08,0x95,0x03,
        0x81,0x06,0xC0,0xC0
    ).map { it.toByte() }.toByteArray()

    private val callback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            onState(if (registered) "Touchpad ready. Pair from the laptop, then tap Connect." else "Touchpad not registered")
        }
        override fun onConnectionStateChanged(device: BluetoothDevice, state: Int) {
            if (state == BluetoothProfile.STATE_CONNECTED) { host = device; onState("Connected to " + device.name) }
            else if (state == BluetoothProfile.STATE_DISCONNECTED) { host = null; onState("Disconnected") }
        }
    }

    private val listener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            val h = proxy as BluetoothHidDevice
            hid = h
            h.registerApp(
                BluetoothHidDeviceAppSdpSettings("Tablet Touchpad", "Touchpad", "TabletLink",
                    BluetoothHidDevice.SUBCLASS1_MOUSE, descriptor),
                null, null, ctx.mainExecutor, callback)
        }
        override fun onServiceDisconnected(profile: Int) { hid = null }
    }

    fun start() {
        if (adapter == null) { onState("No Bluetooth"); return }
        adapter.getProfileProxy(ctx, listener, BluetoothProfile.HID_DEVICE)
    }

    fun bonded(): List<BluetoothDevice> = adapter?.bondedDevices?.toList() ?: emptyList()
    fun connect(d: BluetoothDevice) { hid?.connect(d) }

    private fun send(b: Int, dx: Int, dy: Int, w: Int) {
        val h = host ?: return
        hid?.sendReport(h, 0, byteArrayOf(b.toByte(), dx.coerceIn(-127, 127).toByte(),
            dy.coerceIn(-127, 127).toByte(), w.coerceIn(-127, 127).toByte()))
    }
    fun move(dx: Int, dy: Int, wheel: Int) = send(0, dx, dy, wheel)
    fun click(button: Int) { send(button, 0, 0, 0); send(0, 0, 0, 0) }
}
