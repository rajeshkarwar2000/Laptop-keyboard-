package com.example.tabletlink

import android.view.KeyEvent
import fi.iki.elonen.NanoHTTPD
import org.json.JSONObject

class KeyServer(val pin: String) : NanoHTTPD(8080) {

    private val keys = mapOf(
        "Backspace" to KeyEvent.KEYCODE_DEL, "Delete" to KeyEvent.KEYCODE_FORWARD_DEL,
        "Enter" to KeyEvent.KEYCODE_ENTER, "Tab" to KeyEvent.KEYCODE_TAB,
        "Escape" to KeyEvent.KEYCODE_ESCAPE, "ArrowLeft" to KeyEvent.KEYCODE_DPAD_LEFT,
        "ArrowRight" to KeyEvent.KEYCODE_DPAD_RIGHT, "ArrowUp" to KeyEvent.KEYCODE_DPAD_UP,
        "ArrowDown" to KeyEvent.KEYCODE_DPAD_DOWN, "Home" to KeyEvent.KEYCODE_MOVE_HOME,
        "End" to KeyEvent.KEYCODE_MOVE_END
    )

    override fun serve(session: IHTTPSession): Response {
        val p = session.parms["p"]
        if (p != pin) return newFixedLengthResponse(Response.Status.FORBIDDEN, "text/plain", "Wrong code")
        if (session.method == Method.POST && session.uri == "/k") {
            val body = HashMap<String, String>()
            session.parseBody(body)
            try {
                val j = JSONObject(body["postData"] ?: "{}")
                val svc = RemoteKeyboardService.instance
                if (svc != null) {
                    val v = j.optString("v")
                    when (j.optString("t")) {
                        "text" -> svc.typeText(v)
                        "key" -> {
                            val ctrl = j.optBoolean("ctrl")
                            val code = if (ctrl && v.length == 1 && v[0].lowercaseChar() in 'a'..'z')
                                KeyEvent.KEYCODE_A + (v[0].lowercaseChar() - 'a') else keys[v]
                            if (code != null) svc.key(code, if (ctrl) KeyEvent.META_CTRL_ON else 0)
                        }
                    }
                }
            } catch (_: Exception) {}
            return newFixedLengthResponse("ok")
        }
        return newFixedLengthResponse(Response.Status.OK, "text/html", PAGE.replace("__P__", pin))
    }

    companion object {
        const val PAGE = """<!doctype html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Tablet Link</title>
<style>body{font-family:sans-serif;background:#12121c;color:#eee;display:flex;align-items:center;justify-content:center;height:100vh;margin:0}
#b{padding:40px 60px;border:2px dashed #7aa2ff;border-radius:20px;text-align:center;font-size:22px}</style></head>
<body><div id="b">Keep this tab focused.<br>Type here, text appears on the tablet.<br><small id="s">connected</small></div>
<script>
var P="__P__";
function send(o){fetch('/k?p='+P,{method:'POST',body:JSON.stringify(o)}).catch(function(){document.getElementById('s').textContent='disconnected'});}
var special=['Backspace','Delete','Enter','Tab','Escape','ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'];
document.addEventListener('keydown',function(e){
  if(e.key==='F5'||e.key==='F12')return;
  if(special.indexOf(e.key)>=0){e.preventDefault();send({t:'key',v:e.key});return;}
  if((e.ctrlKey||e.metaKey)&&e.key.length===1){e.preventDefault();send({t:'key',v:e.key,ctrl:true});return;}
  if(e.key.length===1&&!e.altKey){e.preventDefault();send({t:'text',v:e.key});}
});
</script></body></html>"""
    }
}
