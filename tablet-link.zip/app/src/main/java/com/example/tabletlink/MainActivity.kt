package com.example.tabletlink

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface
import kotlin.math.abs

@SuppressLint("MissingPermission", "SetTextI18n")
class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var info: TextView
    private lateinit var mouse: HidMouse
    private var server: KeyServer? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Build.VERSION.SDK_INT >= 31)
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_ADVERTISE), 1)

        mouse = HidMouse(this) { s -> runOnUiThread { status.text = s } }
        val pin = (100000..999999).random().toString()
        server = KeyServer(pin).also { try { it.start() } catch (_: Exception) {} }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#12121c")) }
        info = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 16f; setPadding(30, 20, 30, 10)
            text = "KEYBOARD: on the laptop open\nhttp://" + ip() + ":8080/?p=" + pin
        }
        status = TextView(this).apply { setTextColor(Color.parseColor("#7aa2ff")); setPadding(30, 0, 30, 10); text = "Touchpad: tap 'Start touchpad'" }
        val row1 = LinearLayout(this)
        val row2 = LinearLayout(this)
        fun btn(t: String, r: LinearLayout, f: () -> Unit) = r.addView(Button(this).apply { text = t; setOnClickListener { f() } })
        btn("1. Enable keyboard", row1) { startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)) }
        btn("2. Choose keyboard", row1) { (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showInputMethodPicker() }
        btn("Start touchpad", row2) { mouse.start() }
        btn("Make discoverable", row2) {
            startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300))
        }
        btn("Connect", row2) {
            val list = mouse.bonded()
            AlertDialog.Builder(this).setTitle("Connect to laptop")
                .setItems(list.map { it.name ?: it.address }.toTypedArray()) { _, i -> mouse.connect(list[i]) }.show()
        }
        root.addView(info); root.addView(status); root.addView(row1); root.addView(row2)
        root.addView(pad(), LinearLayout.LayoutParams(-1, 0, 1f).apply { setMargins(20, 20, 20, 20) })
        setContentView(root)
    }

    private fun pad(): View = object : View(this) {
        var lx = 0f; var ly = 0f; var down = 0L; var moved = 0f; var maxP = 0; var sy = 0f
        init { setBackgroundColor(Color.parseColor("#2a2a40")) }
        fun ax(e: MotionEvent) = (0 until e.pointerCount).sumOf { e.getX(it).toDouble() }.toFloat() / e.pointerCount
        fun ay(e: MotionEvent) = (0 until e.pointerCount).sumOf { e.getY(it).toDouble() }.toFloat() / e.pointerCount
        override fun onTouchEvent(e: MotionEvent): Boolean {
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { down = e.eventTime; moved = 0f; maxP = 1; lx = e.x; ly = e.y; sy = 0f }
                MotionEvent.ACTION_POINTER_DOWN -> { maxP = maxOf(maxP, e.pointerCount); lx = ax(e); ly = ay(e) }
                MotionEvent.ACTION_POINTER_UP -> { val i = if (e.actionIndex == 0) 1 else 0; lx = e.getX(i); ly = e.getY(i) }
                MotionEvent.ACTION_MOVE -> {
                    val x = ax(e); val y = ay(e); val dx = x - lx; val dy = y - ly
                    lx = x; ly = y; moved += abs(dx) + abs(dy)
                    if (e.pointerCount >= 2) {
                        sy += dy; val s = (sy / 25).toInt()
                        if (s != 0) { mouse.move(0, 0, -s); sy -= s * 25 }
                    } else mouse.move((dx * 1.6f).toInt(), (dy * 1.6f).toInt(), 0)
                }
                MotionEvent.ACTION_UP -> if (e.eventTime - down < 250 && moved < 20) mouse.click(if (maxP >= 2) 2 else 1)
            }
            return true
        }
    }

    private fun ip(): String {
        for (n in NetworkInterface.getNetworkInterfaces()) for (a in n.inetAddresses)
            if (!a.isLoopbackAddress && a is Inet4Address) return a.hostAddress ?: ""
        return "?"
    }

    override fun onDestroy() { server?.stop(); super.onDestroy() }
}
